'use strict';

module.exports = {
  name: 'sort-order-fallback',

  syntax: ['css', 'less', 'sass', 'scss'],

  accepts: {string: /^abc$/},

  process: function() {},

  detect: () => []
};
