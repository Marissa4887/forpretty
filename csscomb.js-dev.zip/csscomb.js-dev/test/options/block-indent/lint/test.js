describe('Option `block-indent`, lint', function() {
  describe('css', function() {
  });
});
